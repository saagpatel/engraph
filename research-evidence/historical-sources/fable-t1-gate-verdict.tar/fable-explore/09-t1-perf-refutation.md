# 09 — T1's perf premise is refuted at production chunk sizes

**Status:** measured, 2026-07-16
**Verdict:** **do not implement T1.** Packed multi-sequence encoding is slower
than the path engraph already ships, at every production width, on Metal.
**Probe:** `examples/t1_prod_sizing.rs` (this branch)
**Relationship to [08](08-t1-acceptance-decision.md):** 08's acceptance
criterion is unaffected and remains correct. This refutes 08's *payoff*, on
grounds unrelated to numerics. See "What 08 got right and wrong" below.

## What happened

08 was signed to unblock T1 on the strength of a ~3.3× measurement
(`FABLE-T1-NOTES.md` F8: packed 102ms vs sequential 333ms at n=32). Before
implementing, the packed path was measured against production-sized inputs for
the first time. It loses.

## The gap that hid this

Every prior T1 measurement — all four implementations, the whole F2 divergence
matrix, and the F8 speedup — used `fable_t1_diag`'s corpus: ~35-word synthetic
notes. Production chunks are capped at **512 words**
(`split_oversized_chunks(parsed.chunks, &.., 512, 50)`, `src/writer.rs:439`).

So the entire evidence base ran at roughly **1/15th of production token
volume**. F8's "n=32" packed ~1,400 tokens. Production's n=32 packs ~20,000.
Sequence *count* was held to production values while sequence *length* — the
axis the cost actually depends on — was not.

## The measurement

Metal, debug build, embeddinggemma-300M Q8_0, 512-word chunks.
`packed` = `embed_batch_packed`; `production` = today's shipping `embed_batch`
(one shared context, sequential encodes); `control` = fresh context per text.

| n | tokens | packed | production | control | packed vs production | min_cosine |
|---:|---:|---:|---:|---:|---:|---:|
| 2 | 1,267 | 83ms | 82ms | 108ms | 0.99× | 0.999995 |
| 4 | 2,530 | 489ms | 247ms | 179ms | 0.51× | 0.999995 |
| 8 | 5,059 | 856ms | 804ms | 752ms | 0.94× | 0.999995 |
| 16 | 10,126 | 2,055ms | 1,645ms | 1,154ms | 0.80× | 0.999995 |
| 32 | 20,264 | 3,288ms | 2,952ms | 2,578ms | 0.90× | 0.999995 |
| 64 | 40,538 | 14,130ms | 4,395ms | 3,579ms | **0.31×** | 0.999995 |

**Packing never wins.** At `config.batch_size`'s default of 64
(`src/config.rs:154`) — the width production actually runs — it is **3.2×
slower** than the current path. (Rows n=2..32 are a wash within this rig's ~30%
noise floor, quantified later in [10](10-gpu-bound-verdict.md); n=64 is the row
that decides, and it is far outside that band.)

## Why — it is quadratic, and that is not fixable by tuning

Attention cost is O(T²) in the encoded token total. Packing N sequences of
length L creates ONE problem of T = N·L, costing O(N²L²). Encoding them
separately costs N · O(L²). Packing therefore does **N times more attention
work** — it only wins when L is small enough that per-encode fixed overhead
(context creation, graph planning, Metal pipeline setup, dispatch latency)
dominates L². That is exactly the regime the 35-word corpus lives in, and
exactly the regime production does not.

The measured timings carry the signature. Past n=16, packed time roughly
quadruples per doubling (2,055 → 3,288 → 14,130) while the production path
merely doubles (1,645 → 2,952 → 4,395). Quadratic versus linear, as predicted.

Flash-attention's block-skip (`FABLE-T1-NOTES.md` F9 mechanism 1) prunes fully
masked 64-wide blocks, which is why packing degrades rather than collapses —
but it prunes at block granularity, not for free, and it does not recover the
asymptotic difference.

This is a property of the arithmetic, not of the implementation, the build
profile, or the gate. No knob changes it.

## Confidence and caveats

- **Debug build.** Both arms are in the same build and the dominant cost is in
  Metal kernels, not Rust, so the *ratio* is meaningful. A release build speeds
  the tokenizer, not the O(T²) attention. It would not reverse a 3.2× gap.
- **Run-to-run variance is large and was later quantified at ~30% on this rig**
  ([10](10-gpu-bound-verdict.md)). That reclassifies the small-n rows: n=2
  through n=32 are a **wash within noise**, not measured losses, and the n=4
  row (0.51×) should not be read as a real penalty. The claim rests entirely on
  **n=64 — the production width** — where packing is 3.2× slower (14,130ms vs
  4,395ms), reproduced across two runs (17,166ms and 14,130ms against a 4,395ms
  baseline). That gap is an order of magnitude outside the noise band. The
  correct summary is "packing never wins anywhere and loses decisively at the
  width production uses," not "packing loses at every width."
- **Baseline verified, not assumed.** The production shared-context path agrees
  with the fresh-context control at cosine 0.9999994, so the comparison is
  against a sound reference.
- **Synthetic text.** Chunks are generated from a word pool at the production
  512-word cap, not real vault prose. Token totals are what matter for O(T²),
  and those are measured (`token_count`), not estimated.

## What 08 got right and wrong

**Right, and still standing:** the `1e-6` gate was unsatisfiable by any
implementation, and cosine >= 0.999 vs the sequential control is the correct,
calibrated replacement. This probe independently reconfirms the numerics at
production sizes: min_cosine is 0.999995 at **every** width — passing the
signed criterion with ~5× margin on the failure budget. Had T1 been worth
shipping, the signed gate would have been exactly the right bar and it would
have passed.

**Wrong:** 08's Consequences claimed "expected payoff: ~3.3× on the batch-embed
path." That inherited F8 uncritically. 08 did flag "re-measure on release
before claiming a number publicly" — the right instinct, aimed at the wrong
axis. The number was not wrong because of the build profile. It was wrong
because it was measured on text 15× shorter than production's.

## Consequence for the CPU-utilization problem

T1 was the headline fix for the 1998s / 114s CPU (5.6% utilization) reindex
(02-profiling, P6). It is not a fix. That problem is now **unowned** and needs a
different hypothesis.

Worth noting for whoever picks it up: 02 attributed embed time to Metal
`waitUntilCompleted` rather than CPU compute. If the reindex is genuinely
GPU-bound, then low CPU utilization is the *expected* signature of a working
GPU offload, not a defect — and "5.6% CPU utilization" may be framing a healthy
system as a broken one. T1 assumed the wait was amortizable dispatch overhead.
The data above says the GPU is doing real quadratic work, not waiting on
dispatch. That reframe is a hypothesis, not a finding — it has not been
measured, and it should be tested before any successor optimization is scoped.

> **Tested and CONFIRMED same day — see [10](10-gpu-bound-verdict.md).** Metal
> beats a CPU-only control 3.3× at production chunk size, and forcing the same
> workload onto the CPU drives utilization from 8.2% to 361%. The GPU is doing
> the work; the idle CPU is the offload succeeding. P6 is retired, not
> reassigned — there is no unowned problem here, because there was no problem.

## Recommendation

1. **Abandon T1.** Do not implement packed batching. Keep the diagnostic path
   (`embed_batch_packed`, env-gated, unreachable in production) as the evidence
   trail, or drop it — it changes nothing either way.
2. **Keep 08 signed.** It correctly retired an unsatisfiable gate, and the
   criterion it established is the right one if multi-sequence encoding is ever
   revisited after an upstream change.
3. **Re-open the utilization question** with the GPU-bound hypothesis tested
   first, before scoping a replacement optimization.
