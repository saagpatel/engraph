# 10 — The reindex is GPU-bound. P6's premise is retired.

**Status:** measured, 2026-07-16
**Probe:** `examples/t1_gpu_bound.rs` (this branch)
**Verdict:** engraph's embed path is **compute-bound on the GPU**. The 5.6% CPU
utilization that motivated P6 is the expected signature of a working Metal
offload, not a defect. There is no idle machine to reclaim.
**Also here:** a chunk-size optimization was hypothesized, measured, and
**refuted** — and the rig's noise floor, which matters more than either result.

## The question

02-profiling measured a full reindex at 1998s wall / 114s CPU (5.6%
utilization) and attributed embed time to Metal `waitUntilCompleted` rather
than CPU compute. P6/T1 read that as amortizable dispatch overhead: the machine
is idle, so batch harder. [09](09-t1-perf-refutation.md) raised the competing
reading — on a GPU-offloaded workload the CPU is *supposed* to be idle, so 5.6%
may be health, not waste — and flagged it explicitly as untested.

The two readings make different predictions, so they separate by measurement.

## The measurement

Fixed count (n=16), swept chunk size, production `embed_batch` path, Metal vs a
CPU-only control (`ENGRAPH_T1_CPU=1`, `n_gpu_layers=0`). Debug build,
embeddinggemma-300M Q8_0. Whole-process wall/CPU via `/usr/bin/time -p`.

| words | tokens | Metal | CPU | Metal speedup |
|---:|---:|---:|---:|---:|
| 8 | 232 | 108ms | 128ms | 1.2× |
| 64 | 1,329 | 147ms | 845ms | 5.8× |
| 128 | 2,574 | 218ms | 1,460ms | 6.7× |
| 256 | 5,081 | 376ms | 2,504ms | 6.7× |
| 512 (production) | 10,078 | 1,728ms | 5,751ms | **3.3×** |

Whole-process CPU utilization over the identical workload:

| backend | wall | user+sys | CPU utilization |
|---|---:|---:|---:|
| Metal | 14.70s | 1.20s | **8.2%** |
| CPU-only | 12.54s | 45.25s | **361%** |

## What this settles

**The GPU is doing real work.** Metal beats the CPU control by 3.3× at
production chunk size and ~6.7× in the mid range. A path that was merely
waiting on dispatch would not outrun four saturated CPU cores.

**8.2% CPU is the offload working.** Force the same job onto the CPU and
utilization jumps to 361% — four cores genuinely busy. The work exists; on
Metal it simply is not the CPU's work. The reindex's 5.6% is this same
signature at scale. It reproduces here at 8.2%, which corroborates 02's
*measurement* while refuting its *interpretation*.

**P6's premise is dead.** "5.6% utilization" framed a healthy system as a
broken one. There is no idle capacity to reclaim by batching, which is
independently why T1 lost (09): the GPU was never waiting, so there was no wait
to amortize — only quadratic attention to multiply.

## The chunk-size hypothesis: raised, measured, refuted

The sweep above showed Metal µs/token falling to a minimum at 256 words (74)
then nearly doubling at 512 (171), suggesting production chunks
(`split_oversized_chunks(.., 512, 50)`, `writer.rs:439`) sat past an efficiency
optimum and that re-chunking at 256 would roughly halve embed time.

**It does not survive a controlled test.** The sweep varies total work with
size and runs sizes in ascending order, so it confounds size with accumulated
GPU heat. The honest test holds the corpus fixed (8,192 words) and re-chunks
it, alternating order across passes:

| chunk | pass0 (asc) | pass1 (desc) | pass2 (asc) | median |
|---:|---:|---:|---:|---:|
| 64w | 2,319ms | 1,893ms | 1,983ms | 1,983ms |
| 128w | 2,087ms | 1,686ms | 1,710ms | 1,710ms |
| 256w | 1,849ms | 1,667ms | 1,974ms | 1,849ms |
| 512w | 1,474ms | 1,627ms | 1,964ms | **1,627ms** |

Run-to-run spread within a single size is **307-490ms** — larger than any
difference between sizes. The ranges overlap almost entirely, and production's
512w posts the *best* median. There is no chunk-size effect to harvest.

Why the extrapolation was wrong: re-chunking halves attention work but leaves
FFN work unchanged (it is proportional to token count, which is fixed by the
corpus). Attention is not the majority of the cost at ~630 tokens, so halving
it moves little. The apparent 2.3× was thermal drift wearing a curve's clothes.

## The finding that outlives both: this rig's noise floor is ~30%

Repeated identical measurements vary by 307-490ms on a ~1,700ms workload —
roughly **30% run-to-run**. Consequences for the whole campaign:

- **Any embed-path claim under ~1.5×, measured single-shot, is not
  distinguishable from noise.** Several proposals in 03/04 are sized in that
  band and were measured single-shot.
- **Ascending sweeps are actively misleading here.** Sustained GPU load
  throttles, so ordering correlates with heat. Alternate order or randomize.
- **The results that stand do so because they are far outside this band:**
  Metal-vs-CPU (3.3-6.7×), T1's packing penalty (3.2× at n=64, reproduced
  across two runs at 17.2s and 14.1s against a 4.4s baseline), and 03's CLI
  search win (6.4s → 1.1s, ~6×).

Future engraph perf work should report a spread, not a number.

## Caveats

- **Debug build.** Comparisons are between arms within the same build, and the
  dominant cost is in Metal/CPU kernels rather than Rust, so ratios hold. The
  absolute milliseconds are not release figures.
- **Synthetic text** at the production 512-word cap, from a fixed word pool.
  Token totals are measured (`token_count`), not estimated.
- **CPU control forces `n_gpu_layers=0`** on the same machine, so it measures
  this Mac's CPU, not a representative server CPU. The claim is "the GPU is
  doing the work here," not a cross-platform benchmark.
- **`/usr/bin/time` covers the whole process**, including model load and
  tokenization, so 8.2% is a whole-run figure comparable to 02's 5.6%.

## Recommendation

1. **Retire P6.** The 1998s / 5.6% reindex is not a utilization defect. Close
   it as "working as designed" rather than leaving it on the board as the
   headline perf problem.
2. **Do not pursue chunk sizing** for performance. If chunk size changes, it
   should be for retrieval quality; the perf argument is noise.
3. **Adopt a measurement floor** for this rig: report medians across
   order-alternated repeats, and treat sub-1.5× single-shot deltas as unproven.
4. **Reindex wall time remains real** (1998s is 1998s) — but it is the GPU
   doing quadratic-in-chunk-length attention, not slack. A genuine win would
   have to cut work (fewer/smaller vectors, a smaller model, skipping unchanged
   files) rather than rearrange it.
