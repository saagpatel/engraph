# 11 — Auditing 03's live claims against the noise floor

**Status:** measured, 2026-07-16
**Probe:** `examples/perf_claims_audit.rs` (this branch)
**Why:** [10](10-gpu-bound-verdict.md) established a **~30% run-to-run noise
floor** on this rig's embed path. Several claims in
[03-perf-proposals.md](03-perf-proposals.md) are sized inside that band and were
measured single-shot. This re-measures them with repeats and **alternated arm
order**, so heat cannot masquerade as an effect.

**Headline:** one shipped fix is real but ~40% overstated; **P3 dominates P4 and
P4 should be dropped**; the mechanism behind both is now measured rather than
guessed.

## Scope discipline

10's noise floor was measured on *sustained Metal GPU embed under thermal load*.
Applying it to sqlite or CLI timings would be a claim that dropped its
conditions — the exact failure this session keeps finding. So only embed-path
claims are audited here. **P2 (sqlite-vec vs in-memory scan) and P5 (statement
caching) are NOT covered** — different subsystem, needs its own noise floor
before its numbers mean anything. That is open work, not a pass.

A paired comparison with 4 repeats resolves far below 30%: the noise floor
governs *single-shot* claims. A consistent direction across alternated orders is
real even at 1.05×.

## Claim 1 — Fix 4, "one context per embed_batch" (SHIPPED, 7886855)

**On file:** "32-chunk batch 1442ms → 945ms under ambient load (tight-loop
measurements suggest ~2× when quiet)" — i.e. **1.53×**, single-shot, embed path.

**Measured** (n=32, 512-word production chunks, Metal, arm order alternated):

| pass | first | shared | fresh | shared speedup |
|---:|---|---:|---:|---:|
| 0 | shared | 6,137ms | 3,676ms | 0.599 (cold outlier) |
| 1 | fresh | 2,922ms | 3,132ms | 1.072 |
| 2 | shared | 2,919ms | 3,291ms | 1.127 |
| 3 | fresh | 3,023ms | 3,168ms | 1.048 |

**Verdict: real, but ~1.05-1.13×, not 1.53×.** The win holds in both arm orders
across three consecutive passes, so it is a genuine effect and not noise — the
claim's *direction* is sound. Its *magnitude* is inflated by roughly 40%.

Pass 0 is discarded as a cold-start artifact: it is the first large-shape encode
after a small warmup and pays Metal pipeline setup for shapes the warmup never
touched. It is reported rather than silently dropped.

**Why the original number was too big.** The fix removes per-chunk context
creation (~10-15ms/chunk by 03's own estimate). What that is worth depends
entirely on what it is a fraction *of*. At 32 chunks it saves ~380ms flat. If
the original 32-chunk batch really took 1442ms, those chunks averaged ~45ms each
— roughly a 256-word chunk, not production's 512-word (~95ms). At production
size the same flat saving is ~12% of the total, which is exactly the 1.05-1.13×
measured. The 1.53× is not wrong so much as **measured on smaller chunks than
production uses** — the same input-size gap that killed T1 (09).

**Action: keep the fix, correct the number.** It is free, correct, and mildly
positive. Nothing to undo.

## Claim 2 — P4, "consider CPU inference for query-sized encodes"

**On file:** "GPU median 91ms/p90 177ms vs CPU median 39ms for a 12-token
encode" — CPU 2.3× faster, therefore "Metal buys nothing at query size."

**Measured** (`embed_one`, the real query path, 7-token query, 20 encodes/pass):

| backend | pass0 | pass1 | pass2 | pass3 | median |
|---|---:|---:|---:|---:|---:|
| Metal | 13.51ms | 11.81ms | 12.43ms | 12.18ms | **12.3ms** |
| CPU | 7.83ms | 7.05ms | 7.37ms | 8.10ms | **7.6ms** |

**Direction replicates and is solid** — CPU is 1.62× faster, and the ranges do
not overlap at all (CPU max 8.10 < Metal min 11.81). This is not a noise
artifact.

**The absolute numbers do not replicate, by ~7×.** P4 measured 91ms on GPU where
this measures 12.3ms. 03 attributes its figures to ambient load, GPU queue
contention with Ollama, and power-state ramp — so 91ms was a *contended machine*,
not a structural property. Any decision resting on 91ms was resting on weather.

## The finding that resolves both: the penalty is context creation, not compute

Cross-referencing 10's sweep against this one localizes the Metal query penalty
precisely:

| encode | context | Metal | CPU | winner |
|---|---|---:|---:|---|
| ~14 tokens ([10](10-gpu-bound-verdict.md), `embed_batch` n=16) | **shared** | 6.78ms | 7.98ms | **Metal** |
| 7 tokens (here, `embed_one`) | **fresh per call** | 12.3ms | 7.6ms | **CPU** |

Metal *wins* at query size with a shared context and *loses* with a fresh one.
The delta is ~5.5ms of Metal context/pipeline setup per call; CPU's equivalent
is near zero. So Metal's query-path disadvantage is **entirely fixed per-call
setup, not slow compute** — consistent with 10, where Metal beats CPU 3.3× once
the encode is big enough to amortize that setup.

(Approximate: the two rows differ in token count, 14 vs 7, and shared-context
per-text cost is not purely encode. The decomposition is directional; the
Metal-wins/Metal-loses flip across the context condition is the solid part.)

### Therefore P3 dominates P4

- **P4** (route queries to CPU) *works around* the 5.5ms setup by abandoning the
  faster compute engine. Ceiling: 7.6ms.
- **P3** (actor thread owning model+context, reusing it across queries)
  *removes* the 5.5ms and keeps Metal. Ceiling: ~6.8ms — and it also serializes
  GPU submissions, which is what made P4's 91ms contention happen in the first
  place.

P3 is faster, fixes the actual mechanism, and subsumes P4's benefit. **Drop P4.**
03's own text called this shot — "Worth re-measuring after P3 — context reuse may
make GPU competitive again at the floor" — and it was right; nobody had tested it.

**P3's own claim** ("reused-context tight-loop embeds 10-11ms stable vs 25ms+
fresh", ~2.3×) also holds in direction with better absolutes: ~6.8ms reused vs
12.3ms fresh, **~1.8× on the query path**.

## Caveats

- **Debug build.** Arms are compared within one build; ratios hold, absolute
  milliseconds are not release figures.
- **Synthetic text**; token counts measured via `token_count`, not estimated.
- **A quiet machine.** P4's numbers came from a contended one. That cuts both
  ways: 12.3ms is the uncontended Metal figure, and a live machine running 10+
  serve processes plus Ollama will be worse. It does not rescue P4 — P3 helps
  contention *more*, by serializing submissions.
- **P3's ceiling is inferred** from shared-context batch encodes, not from a
  built actor. It is a bound, not a delivered number.

## Recommendation

1. **Correct fix 4's claim** in 03 from 1.53× to ~1.05-1.13× at production chunk
   size. Keep the code.
2. **Drop P4.** Superseded by P3 on measurement, not opinion.
3. **P3 is the best remaining query-path lever** on the board: ~1.8×, and it
   attacks the mechanism (per-call Metal setup + unserialized GPU submissions)
   that produced P4's pathological 91ms in the first place.
4. **P2 and P5 remain unaudited.** Measure sqlite's own noise floor before
   trusting "15-336ms median ~35ms vs 3.5-9ms" — the 22× spread in that range is
   itself a warning that it was measured on a noisy surface.
